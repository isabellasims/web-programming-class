- add question mark in upper right w/ alert that says type finished task to remove from list
- be able to return to submit new things to the list
- button to toggle background between pale pink and ghost white



