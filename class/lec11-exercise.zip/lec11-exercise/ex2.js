function string_to_array(string){
    let parsed = string.split(" ");
    parsed = parsed.toString();
    return parsed;

}

alert(string_to_array("Monday is blue"));
