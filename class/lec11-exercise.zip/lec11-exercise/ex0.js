window.onload = function(){
    let okButton = document.getElementById('ok');
    okButton.onclick = function () {
        alert('Booyah');
    };
};
