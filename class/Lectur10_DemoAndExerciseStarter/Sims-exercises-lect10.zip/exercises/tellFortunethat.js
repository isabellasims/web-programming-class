
let tellFortuneThat = function(numChildren, partnerName, location, jobTitle){
    document.write("you will be a ", jobTitle, " in " , location, " and married to " , partnerName, " with ", numChildren, " kids.");
    document.write("<br>");
    document.write("<br>");

};

tellFortuneThat(5, "Andrew", "New York City", "CEO");
tellFortuneThat(1, "Anna", "Washington, DC", "politician");
tellFortuneThat(3, "Sam", "Chicago", "software engineer");
