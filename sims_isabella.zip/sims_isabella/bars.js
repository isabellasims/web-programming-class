// will eventually do this for interaction / to animate the bars

function setup()
{
    let bars = select('bar');
    fill(150);          // Setting the interior of a shape (fill) to grey
    rect(50, 50, 75, 100);

}
