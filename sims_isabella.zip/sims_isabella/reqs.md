[X]10 unique tags

    [X] html
    [X] head
    [X] body
    [X] title
    [X] div
    [X] h3
    [X] h2
    [X] h1
    [X] p
    [X] footer

[X] 10 different selectors / rules

    [X] .resume
    []
    []
    []
    []
    []
    []
    []
    []
    []

[X] 3 element ids

    [] 
    []
    []


[X] 5 classes

    []
    []
    []
    (shared) [] 
    (shared) []
    



