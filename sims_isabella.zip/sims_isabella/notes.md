references / inspo

- like the live movement of languages: https://templateflip.com/demo/templates/right-resume/

- https://alvaromontoro.com/files/resume-modern.html
    - I like the folding tabs
    - I want mine to autoscale like this one eventually
